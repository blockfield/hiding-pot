#!/bin/bash

# Run likelib node

node deploy_contract.js
#If contract address not KLyfjrcGTKYEQLrCSKt1REyGJ8B, change address in call_contract.js
node call_contract.js

